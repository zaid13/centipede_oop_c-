/*
 * Mushroom.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "Mushroom.h"

int rand_number;
int getpix(){

	srand(time(0));
	rand_number = rand()%500;

		int xx = rand_number;

}

std::string codeword;


void Mushroom::draw(){
int col = GREEN;
	if(bulletscount==0){
		col = GREEN;

		DrawSquare( p.getx() ,p.gety(),15,colors[col]);

	}
	if(bulletscount==1){
			col = CYAN;

			DrawSquare( p.getx() ,p.gety(),15,colors[col]);

	}

}
Mushroom::Mushroom(){
	bulletscount=0;
	BrickNo= 29;

	srand(time(0));
	rand_number = rand()%500;

		int xx = rand_number;
		int yy= rand()%1000 ;
		for(int i =0 ; i<BrickNo ; i++){
		p.setx(getpix());
		p.sety(getpix());
}}

Mushroom::Mushroom(int a ,int b){

	this->p.setx(a);
	this->p.sety(b);

}

void Mushroom::mushroomposition(int a,int b){
this->p.setx(a);
this->p.sety(b);


}

