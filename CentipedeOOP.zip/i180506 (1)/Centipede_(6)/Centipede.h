/*
 * Centipede.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef CENTIPEDE_H_
#define CENTIPEDE_H_
#include "Segments.h"
#include "util.h"

#include <iostream>
using namespace std;
class Centipede {
	bool down;
	int direction;
	Segments *seg;
	int size;
	bool rightleft;
public:
	Centipede();

	Centipede(Segments* s ,int sz);
virtual	void draw();
	int getsize();
		Segments* getseg();
//	Segments& getrefseg();

		void	hitleft();
		void	hitright();

	void setdirection(int t){direction = t;}
	void setsize(int a);
	void setSeg(Segments* s);
	void moveright();
	void moveleft();
	void moveup();

	void movedown();
	int getcentidirection();
	void setdown(bool w){this->down = w;}
	bool getdown(){return this->down;}
};

#endif /* CENTIPEDE_H_ */
