/*
 * MagicSeg.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "MagicSeg.h"

