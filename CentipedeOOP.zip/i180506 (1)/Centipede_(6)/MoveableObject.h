/*
 * MoveableObject.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */
//enum Dir{UP, DOWN, RIGHT,LEFT};
#ifndef MOVEABLEOBJECT_H_
#define MOVEABLEOBJECT_H_
#include"GameObject.h"
class MoveableObject :public GameObject {
protected:
int direction;
int speed;
public:
void moveright(){
	this->p.setx(this->p.getx()+1);
}
void moveleft(){
	this->p.setx(this->p.getx()-1);
}void moveup(){
	this->p.sety(this->p.gety()+1);
}void movedown(){
	this->p.sety(this->p.gety()-1);
}

};

#endif /* MOVEABLEOBJECT_H_ */
