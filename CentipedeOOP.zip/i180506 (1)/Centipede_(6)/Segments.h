/*
 * Segments.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef SEGMENTS_H_
#define SEGMENTS_H_
#include "MoveableObject.h"
class Segments: public MoveableObject {
public:
	int direction ; //  left 0 down 1 right 2
int getx();
int gety();
void setx(int a);
void sety(int b);
void setdir(int str);
virtual void draw(){}
int getdirection(){return this->direction;}
};

#endif /* SEGMENTS_H_ */
