/*
 * GameObject.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "GameObject.h"

GameObject::GameObject(){

}
GameObject::GameObject(Position l){
p= l ;
}

Position GameObject::getp(){
return p;

}

