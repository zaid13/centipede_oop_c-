/*
 * Player.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "Player.h"
void Player::draw(){
	srand(time(0));
	int colo[13];
	for(int i=0; i<14 ; i++){
		colo[i]  = rand()%120;

	}
	DrawSquare(p.getx()+3,p.gety()-27,15,colors[colo[0]]);
	DrawCircle(p.getx()+10,p.gety()-5,12,colors[colo[1]]);
	DrawTriangle(p.getx(), p.gety(), p.getx()+20, p.gety() , p.getx()+10 , p.gety()+25, colors[colo[2]] );
	DrawCircle(p.getx()+3,p.gety()-3,4,colors[colo[3]]);
	DrawCircle(p.getx()+17,p.gety()-3,4,colors[colo[4]]);
	DrawLine( p.getx()+2 , p.gety()+5 , p.getx()+18 ,p.gety()+5 , 2 , colors[colo[5]] );
	DrawLine( p.getx()+4 , p.gety()+10 , p.getx()+16 ,p.gety()+10 , 2 , colors[colo[6]] );
	DrawLine( p.getx()+6 , p.gety()+15 , p.getx()+14 ,p.gety()+15 , 2 , colors[colo[7]] );
	DrawLine( p.getx()+2 , p.gety()-15 , p.getx()+18 ,p.gety()-15 , 2 , colors[colo[8]] );
	DrawLine( p.getx()+4 , p.gety()-25 , p.getx()+17 ,p.gety()-25 , 2 , colors[colo[9]] );
	DrawLine( p.getx()+6 , p.gety()-20 , p.getx()+13 ,p.gety()-20 , 2 , colors[colo[10]] );
	DrawLine( p.getx()+8 , p.gety()+20 , p.getx()+12 ,p.gety()+20 , 2 , colors[colo[11]] );
}

Position Player::getplayerposition(){
return this->p;
}

int Player::getplayerx(){
	return this->p.getx();
}
int Player::getplayery(){
	return this->p.gety();
}
void Player::setplayery(int a){if(a>50 && a< 200 ){this->p.sety(a);}}
void Player::setplayerx(int a){if(a>50 && a< 900 )this->p.setx(a);}
void Player::setfire(bool a){
	fire =a;
}
