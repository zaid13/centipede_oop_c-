/*
 * Player.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef PLAYER_H_
#define PLAYER_H_

#include"MoveableObject.h"
class Player :MoveableObject{
	bool fire;
public:
	Player(){
		this->p.sety(0);
		this->p.setx(0);
	}
	virtual void draw();
	Position getplayerposition();
	int getplayerx();
	int getplayery();
	void setplayery(int a);
	void setplayerx(int a);
	void setfire(bool a);

};

#endif /* PLAYER_H_ */
