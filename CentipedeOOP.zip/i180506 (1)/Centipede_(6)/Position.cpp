/*
 * Position.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "Position.h"

	Position::Position(){
		x=20;
		y=20;
	}
	Position::Position(int a,int b){
		x=a;
		y=b;
	}

int	Position:: getx(){
		return x;
	}
int	Position:: gety(){
	return y;
}
void	Position:: setx(int a){x = a;}
void	Position::sety(int b){y =b;}
