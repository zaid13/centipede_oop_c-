/*
 * MagicSeg.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef MAGICSEG_H_
#define MAGICSEG_H_

class MagicSeg {
};

#endif /* MAGICSEG_H_ */
