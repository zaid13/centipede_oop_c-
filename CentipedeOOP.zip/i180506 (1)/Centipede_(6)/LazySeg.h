/*
 * LazySeg.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef LAZYSEG_H_
#define LAZYSEG_H_

class LazySeg {
};

#endif /* LAZYSEG_H_ */
