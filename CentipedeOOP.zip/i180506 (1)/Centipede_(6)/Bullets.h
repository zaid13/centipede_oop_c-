/*
 * Bullets.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef BULLETS_H_
#define BULLETS_H_
#include <GL/glut.h>
#include "util.h"
#include "MoveableObject.h"
#include "Player.h"

class Bullets :public MoveableObject{

bool hit;
public :
virtual	void draw(){

}
Bullets(){
	p.setx(660);
	p.setx(660);
	this->hit= false;
}
void setbulletposition(int a,int b){
	p.setx(a);
	p.sety(b);

}
int getbulletpositionx(){return p.getx();}
int getbulletpositiony(){return p.gety();}
void sethit(bool a){
	this->hit =a;
}
bool gethit(){return hit;}

};

#endif /* BULLETS_H_ */
