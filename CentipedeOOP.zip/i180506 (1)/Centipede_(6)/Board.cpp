/*
 * Board.cpp
 *  Created on: May 2, 2014
 *      Author: Sibt ul Hussain
 */

#include "Board.h"
#include <cstdio>
#include<vector>
#include <cstdlib>
#include <time.h>
//
// Asteroids board
//
// Note that all these enum constants from NILL onwards
// have been given numbers in increasing order
// e.g. NILL=0, and so on
// and these numbers are represented in the board array...
enum BoardParts {
	NILL, S_BRICK, G_BRICK, R_BRICK
};
// defining some utility functions...
/* board_array[Board::BOARD_Y][Board::BOARD_X] = { { 0 } };*/
// Destructor
Board::~Board(void) {}
void Board::InitalizeBoard(int w, int h) {
	cent = new Centipede[1];
noofcentipede = 1;

	cout << "Initialize board" << endl;
	width = w;
	height = h;
	for (int i = 0; i < BOARD_Y - 1; ++i) {
		for (int j = 0; j < BOARD_X; ++j) {
			// can use G_BRICK, R_BRICK, or S_BRICK here
			board_array[i][j] = NILL;
		}
	}

	noofbullets=0;
	player.setplayerx(500);
player.setplayery(100);
for(int i= 0; i< noofbullets ; i++){
fire[i].setbulletposition(500,100);
}
}
//Constructor

void Board::callnewflyer(){

	flyer = new Flea[noofflyer+1];

	noofflyer++;
}
Board::Board(int xsize, int ysize) {
	noofbricks =20;
	noofflyer = 1;
	flyer = new Flea[noofflyer];
	cout << "Constructor board" << endl;
	xcellsize = xsize;
	ycellsize = ysize;
	pcolor = CHOCOLATE;
	bcolor = ORANGE_RED;
	gcolor = PINK;
	for (int i = 0; i < BOARD_Y; ++i)
		for (int j = 0; j < BOARD_X; ++j)
			board_array[i][j] = 0;
//set up board
	brick = new Mushroom[noofbricks];
srand(time(0));
int posx,posy;
for(int i=0 ; i<noofbricks ; i++){


do{ posx=rand()%47;}while(posx<3);
do{ posx=rand()%47;}while(posx<3);

//for(int j=0 ; j< i ; j++){
//if(posx==brick[j].getMushx()){
//	posx=rand()%94;
//	break;
//}

do{ posy=rand()%36;}while(posy<5);
int t ;
do{ t=rand()%36;}while(t<6);

flyer[noofflyer-1].Fleaposition(posx*20,750);
flyer[noofflyer-1].flyeroff();

brick[i].setpumpkinbullets(0);
	brick[i].setMushroomX(t*20,posy*20);
 fire = new Bullets[1000];
	//vector<Bullets> fire;
noofbullets = 0;
}
}

void Board::collisiocentibullet(){
	for(int i=0 ; i<noofbullets ; i++){
		for(int k=0  ; k<noofcentipede  ; k++) {
 int y = cent[k].getsize();
			for(int j=0 ; j<cent[k].getsize() ;j++){

				if( cent[k].getseg()[j].getx()-fire[i].getbulletpositionx() <10  && fire[i].getbulletpositionx()-cent[k].getseg()[j].getx() <10 && fire[i].getbulletpositiony()- cent[k].getseg()[j].gety()<10 && cent[k].getseg()[j].gety()-fire[i].getbulletpositiony()<10 )  {
					if(fire[i].gethit()==false){
//
						cent[k].setsize(y-(y-j));
						int tempdir= 0;
						if(cent[k].getcentidirection()==0){
							tempdir = 2;
						}
						if(cent[k].getcentidirection()==2){
							tempdir = 0;
						}
						Mushroom b;
												b.setMushroomX(cent[k].getseg()[j].getx(),cent[k].getseg()[j].gety());
												bricksadder(b);
												fire[i].sethit(true);
												if(j==0){		stats.increasescore(100);
												}
												else{		stats.increasescore(10);
												}
												addcentepede(cent[k].getseg()[j].getx(), cent[k].getseg()[j].gety(),  cent[k].getseg()[j] ,j+1,cent[k].getdown()  , y-j , tempdir);
					}

				}}
		}}
}



void Board::bricksadder(Mushroom b){

Mushroom *temp;
temp = new Mushroom[noofbricks];
for(int i=0  ;i< noofbricks ; i++ ){
	temp[i].setMushroomX(brick[i].getMushx(),brick[i].getMushy());
    temp[i].setpumpkinbullets(brick[i].getbulletcount());
}
delete []brick;
brick = new Mushroom[noofbricks+1];

for(int i=0  ;i< noofbricks ; i++ ){
	brick[i].setMushroomX(temp[i].getMushx(),temp[i].getMushy());
    brick[i].setpumpkinbullets(temp[i].getbulletcount());
}

brick[noofbricks].setMushroomX(b.getMushx(),b.getMushy());
brick[noofbricks].setpumpkinbullets(b.getbulletcount());


noofbricks++;

}



void Board::movebulletsup(){
	for(int i= 0; i< noofbullets ; i++){
		this->fire[i].setbulletposition(this->fire[i].getbulletpositionx(),this->fire[i].getbulletpositiony()+10);}

}

void Board::mushroomdetector(){
	for(int i=0 ; i<noofbricks ; i++){
		for(int k= 0 ; k<noofcentipede ; k++){
		if( cent[k].getseg()[0].getx()-brick[i].getMushx() <20  && brick[i].getMushx()-cent[k].getseg()[0].getx() <20 && brick[i].getMushy()- cent[k].getseg()[0].gety()<10 && cent[k].getseg()[0].gety()-brick[i].getMushy()<20 )  {
			if(brick[i].getbulletcount()<2)
			{
				if(cent[k].getcentidirection()==0){
					cent[k].hitleft();
				}
			if(cent[k].getcentidirection()==2){
				cent[k].hitright();
			}
		}}
		}
		  }

}
void Board::movefleasdown(){
	flyer[noofflyer-1].Fleaposition(flyer[noofflyer-1].Fleagetx(),flyer[noofflyer-1].Fleagety()-10);

}
void Board::checkbullethitbrick(){

	for(int i=0 ; i<noofbricks ; i++){
		for(int j=0 ; j< noofbullets ;j++ ){
			if( fire[j].getbulletpositionx()-brick[i].getMushx() <20  && brick[i].getMushx()-fire[j].getbulletpositionx() <5 && brick[i].getMushy()- fire[j].getbulletpositiony()<10 && fire[j].getbulletpositiony()-brick[i].getMushy()<20 )  {

				if(fire[j].gethit()==false){
					if(brick[i].getbulletcount()<2){
						brick[i].increasepumpkinbullets();

						fire[j].sethit(true);
						//
						cout<<fire[j].gethit()<<endl<<endl;

						if(brick[i].getbulletcount()==2)
						{stats.increasescore(1);
						brick[i].increasepumpkinbullets();
						}

					}}}}
	}

}
void Board::Draw() {
	glColor3f(0, 0, 1);
	glPushMatrix();
	for(int i  = 0 ; i<noofcentipede ; i++)
	{cent[i].draw();}

	for(int i=0 ; i< 10 ; i++)
	{

	mushroomdetector();
	checkbullethitbrick();
	collisiocentibullet();
	if(flyer[noofflyer-1].getflyerstatus()){
	collisionplayerFlea();}
	movebulletsup();
	collisonfleebullet();
	}
	collisionplayersnake();
//	collisonfleebullet();
	player.draw();


	for(int i= 0; i< noofbullets ; i++){
//		fire[i].sethit(true);
		if(fire[i].gethit()==false){
	DrawLine(fire[i].getbulletpositionx() +10, fire[i].getbulletpositiony(), fire[i].getbulletpositionx()+10 , fire[i].getbulletpositiony()+10, 4 , colors[YELLOW] );
}	}
	int randbooli = rand()%2;


	if(randbooli==1 ){

		if(rand()%2){
//		callnewflyer();
		flyer[noofflyer-1].flyeron();
		int posx;
		do{ posx=rand()%36;}while(posx<5);

		flyer[noofflyer-1].Fleaposition(posx*20,750);
		flyer[noofflyer-1].flyeron();

		//		flyer[noofflyer-1].flyeroff();

	}}
	if(flyer[noofflyer-1].getflyerstatus()){
		flyer[noofflyer-1].draw();
	for(int  i= 0 ; i< 10 ; i++){	flyer[noofflyer-1].movedown();}
	}

	for(int i=0 ; i<noofbricks ; i++){
		brick[i].draw();	}

	//DrawSquare( 400 , 20 ,40,colors[RED]);
	//Mushroom
	//Display Score
	////////////////////////////////////////////////////////////

	int randbool = rand()%8;
	if(randbool==4 ){flyer[noofflyer-1].flyerYesProductive();}
	else
	{flyer[noofflyer-1].flyerNOProductive();}

	if( flyer[noofflyer-1].getflyerstatus()==true && flyer[noofflyer-1].getproductive()){Mushroom re;
	re.setMushroomX(flyer[noofflyer-1].Fleagetx(),flyer[noofflyer-1].Fleagety());
	re.setpumpkinbullets(0);
	bricksadder(re);}


	/////////////////////////


	stringstream ss,a;
string scr,lev,master= "Score =" ;

ss<<stats.getscore();
ss>>scr;
master+=scr;
master +="                                                                  life :";
////////////////

if(3-stats.getlife()==3)
{DrawLine( 600,840 ,  600 , 800 , 5 , colors[VIOLET] );
DrawLine( 620,840 ,  620 , 800 , 5 , colors[VIOLET] );
DrawLine( 640,840 ,  640 , 800 , 5 , colors[VIOLET] );
}
if(3-stats.getlife()==1)
{DrawLine( 600,840 ,  600 , 800 , 5 , colors[VIOLET] );
}

cout<<stats.getlife();
if(3-stats.getlife()==2)
{DrawLine( 600,840 ,  600 , 800 , 5 , colors[VIOLET] );
DrawLine( 620,840 ,  620 , 800 , 5 , colors[VIOLET] );
}



	DrawString( 50, 800, master, colors[MISTY_ROSE]);
	//Spider
	// Trianlge Vertices v1(300,50) , v2(500,50) , v3(400,250)
//	DrawLine(int x1, int y1, int x2, int y2, int lwidth, float *color)
	DrawLine( 950, 750 ,  950 , 50 , 10 , colors[MISTY_ROSE] );
	DrawLine( 50 , 750 , 950  ,750 , 10 , colors[MISTY_ROSE] );
	DrawLine( 50 , 750 ,  50  , 50 , 10 , colors[MISTY_ROSE] );
	DrawLine( 50 , 50  ,  950 , 50 , 10 , colors[MISTY_ROSE] );
	for (int i = BOARD_Y - 2, y = 0; i >= 0; --i, y += xcellsize) {
		for (int j = 0, x = 0; j < BOARD_X; j++, x += (ycellsize)) {
			//			cout <<      " " << board_array[i][j] << " " << flush;
			switch (board_array[i][j]) {
			case NILL:
				// Empty space
				break;
			case S_BRICK:
				DrawRectangle(x - 10, y, ycellsize, xcellsize,
						colors[SLATE_GRAY]);
				//DrawLine(x - 10, y, x - 10 + ycellsize, y, 4, colors[BLACK]);
				break;
			case G_BRICK:
				DrawRectangle(x - 10, y, ycellsize, xcellsize,
						colors[LIGHT_GREEN]);
				break;
			case R_BRICK:
				DrawRectangle(x - 10, y, ycellsize, xcellsize, colors[RED]);
				break;
			} }	}
	if(stats.getlife()>=3){
		DrawSquare( 0 , 0 ,10000,colors[BLACK]);

		DrawString( 600, 400, "GAME OVER", colors[MISTY_ROSE]);

	}

	glPopMatrix();}

void Board::collisionplayerFlea(){
if(flyer[noofflyer-1].getflyerstatus()){
	if((	(player.getplayerx()- flyer[noofflyer-1].Fleagetx())<20 )    &&    (((flyer[noofflyer-1].Fleagetx() -	player.getplayerx()) )<20) &&      ((player.getplayery()- flyer[noofflyer-1].Fleagety())<20) &&(( flyer[noofflyer-1].Fleagety() -	player.getplayery())<20)){

	stats.increaselife();


//cout<<"was here incollisojn";
cout<<player.getplayerx()<< "       "<<flyer[noofflyer-1].Fleagetx()<<endl;
//cout<<"was here incollisojn";
flyer[noofflyer-1].flyeroff();

}}
}
void Board::collisionplayersnake(){
	for(int k= 0 ; k<noofcentipede ; k++){
		for(int i=0; i<1 ; i++){
			if( cent[k].getseg()[i].getx()-player.getplayerx()<10  && player.getplayerx()-cent[k].getseg()[i].getx()<10 &&player.getplayery()-cent[k].getseg()[i].gety()<30 && cent[k].getseg()[i].gety()-player.getplayery()<30 ){
				int t;
				cout<<"4";
				//cin>>t;
				cout<<"4";
				stats.increaselife();
				}
			}

		}}
void Board::collisonfleebullet(){

	for(int i=0 ; i<noofflyer ; i++){
		for(int j=0 ; j< noofbullets ;j++ ){
			if( fire[j].getbulletpositionx()-flyer[noofflyer-1].Fleagetx()<20  && flyer[noofflyer-1].Fleagetx()-fire[j].getbulletpositionx() <5 && flyer[noofflyer-1].Fleagety()-fire[j].getbulletpositiony()<5 &&fire[j].getbulletpositiony() - flyer[noofflyer-1].Fleagety()<20 )  {
				flyer[noofflyer-1].flyeroff();
				stats.increasescore(200);

	}
		}}
}


void Board::addcentepede(int a,int b ,Segments s ,int index, bool w,int size,int dir){



	Centipede * temp = new Centipede[noofcentipede];
	for(int i=0 ; i< noofcentipede ; i++){

		temp[i].setsize(cent[i].getsize());
		temp[i].setdirection(cent[i].getcentidirection());
		temp[i].setdown(cent[i].getdown());
		temp[i].getseg()[0].setx(cent[i].getseg()[0].getx());
		temp[i].getseg()[0].sety(cent[i].getseg()[0].gety());

	}
//	delete []cent;
	cent =  new Centipede[noofcentipede+1];

	for(int i=0 ; i< noofcentipede ; i++){
		cent[i].setsize(temp[i].getsize());
		cent[i].setdirection(temp[i].getcentidirection());
		cent[i].setdown(temp[i].getdown());
		cent[i].getseg()[0].setx(temp[i].getseg()[0].getx());
		cent[i].getseg()[0].sety(temp[i].getseg()[0].gety());


	}

	cent[noofcentipede].getseg()[0].setx(a);
	cent[noofcentipede].getseg()[0].sety(b);
	cent[noofcentipede].setdirection(dir);
	cent[noofcentipede].setsize(size);
	cent[noofcentipede].setdown(w);




noofcentipede++;
}
void Board::GetInitTextPosition(int &x, int &y) {
	x = xcellsize;
	y = (BOARD_Y - 1) * ycellsize + ycellsize / 2;
}
