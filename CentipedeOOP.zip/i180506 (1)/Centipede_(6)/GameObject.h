/*
 * GameObject.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef GAMEOBJECT_H_
#define GAMEOBJECT_H_
#include "Position.h"
#include <GL/glut.h>
#include "util.h"

class GameObject {
protected:
Position p;

public:
virtual void draw()=0;
GameObject();
GameObject(Position l);
Position getp();
};

#endif /* GAMEOBJECT_H_ */
