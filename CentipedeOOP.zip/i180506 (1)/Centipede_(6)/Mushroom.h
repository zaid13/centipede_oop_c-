/*
 * Mushroom.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef MUSHROOM_H_
#define MUSHROOM_H_
#include"GameObject.h"
#include <time.h>
#include <cstdlib>

class Mushroom:public GameObject  {
protected:
	int BrickNo;
	int bulletscount;

public:
	void draw();
	Mushroom();
	Mushroom(int a ,int b);
	void mushroomposition(int a,int b);
	Position getPosMush(){
		return p;
	}
	void setMushroomX(int a,int b){
		p.setx(a);
		p.sety(b);}
	int getMushx(){return p.getx();}
	int getMushy(){return p.gety();}
void increasepumpkinbullets(){
	bulletscount++;

}

void setpumpkinbullets(int i){

	bulletscount = i;

}
int getbulletcount(){return bulletscount;}


};

#endif /* MUSHROOM_H_ */
