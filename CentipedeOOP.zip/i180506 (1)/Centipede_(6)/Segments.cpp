/*
 * Segments.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "Segments.h"

int Segments::getx(){
return p.getx();
}

int Segments::gety(){
	return p.gety();
}
void Segments::setx(int a){
	p.setx(a);
}
void Segments::sety(int b){
	p.sety(b);
}
void Segments::setdir(int str){
	direction  = str;
}
