/*
 * Centipede.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "Centipede.h"
#include <GL/glut.h>


void Centipede::moveright(){
		seg[0].setx(seg[0].getx()+1);
}
void Centipede::moveleft(){
			seg[0].setx(seg[0].getx()-1);
	}
void Centipede::moveup(){
	seg[0].sety(seg[0].gety()+20);
}void Centipede::movedown(){
		seg[0].sety(seg[0].gety()-20);
}
void Centipede::hitleft(){

	if(down==true){movedown();}
	else{
			moveup();
			}
	direction = 2;

}
void Centipede::hitright(){
	if(down==true){movedown();}
	else{
		moveup();
		}
	direction = 0;

}
Centipede::Centipede(){
	size = 20;
direction = 0;
down = true;
seg = new Segments[size];
for(int i =0 ; i<size ; i++){
seg[i].setx(950);
seg[i].sety(730);
                  seg->setdir(0);

                  rightleft = true;
}
}
Centipede::Centipede(Segments* s ,int sz){
	seg= s;
	size = sz;

}
	void Centipede::draw(){

		int gap = 0;
		int xgap,ygap;
		srand(time(0));
		int colo;
		for(int i=0; i<14 ; i++){
			colo  = rand()%120;

		}
		for(int i=size-1 ; i>0 ; i--){

			seg[i].setx(seg[i-1].getx());
	seg[i].sety(seg[i-1].gety());

		}
		if(size > 0 ){
			for(int i=0 ; i<size ; i++){
				DrawCircle(seg[i].getx(),seg[i].gety(),10,colors[RED]);//
				DrawLine( seg[i].getx() , seg[i].gety()+13 , seg[i].getx()  ,seg[i].gety()-13 , 2 , colors[GRAY] );
				DrawLine( seg[i].getx()+3 , seg[i].gety()+13 , seg[i].getx()+3  ,seg[i].gety()-13 , 2 , colors[GRAY] );

				if(i==1){
					if(direction==0){
						DrawCircle(seg[i].getx()+4,seg[i].gety(),7,colors[ORANGE]);//
						DrawCircle(seg[i].getx(),seg[i].gety(),10,colors[colo]);//
						DrawLine( seg[i].getx() , seg[i].gety()+13 , seg[i].getx()  ,seg[i].gety()-13 , 2 , colors[GRAY] );
						DrawLine( seg[i].getx()+3 , seg[i].gety()+13 , seg[i].getx()+3  ,seg[i].gety()-13 , 2 , colors[GRAY] );

					}else
					{DrawCircle(seg[i].getx()-4,seg[i].gety(),7,colors[ORANGE]);//
					}
				}
			}
		}

for(int i=0 ; i<40-size ; i++){
	if(seg[i].getx()>90 && direction ==0  )  //regular            left
	{
		moveleft();
	}
	if(seg[i].getx()<930 && direction ==2  ){  //regular right

		moveright();
	}

	if(seg[i].getx()<100 && seg[0].gety()<=90    )   //hit bottom down
	{
	 	down =false;
	}
	if(seg[i].getx()>920 &&seg[0].gety()>700   )   //hit bottom up   /
	{
		down =true;
	}

	if(seg[0].getx()<90 && direction  == 0  ){   //detect left
		direction= 2;

		hitleft();

}if(seg[0].getx()>930 && direction  ==  2 ){  //detect right

direction= 0;

hitright();

}




}


	}
	int Centipede::getcentidirection(){
		return this->direction;
	}


	int Centipede::getsize(){
		return this->size;
	}
	Segments* Centipede::getseg(){return this->seg;}
//	Segments& Centipede::getrefseg(){return *seg;}

	void Centipede::setsize(int a){this->size =a;}
	void Centipede::setSeg(Segments* s){this->seg= s;}
