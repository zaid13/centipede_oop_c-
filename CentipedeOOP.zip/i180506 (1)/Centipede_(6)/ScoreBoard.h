/*
 * ScoreBoard.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef SCOREBOARD_H_
#define SCOREBOARD_H_

class ScoreBoard {
protected :
	int level ;
	int score;
	int life;
public:
	int getlevel(){return level;}
	int getscore(){return score;}
	int getlife(){return life;}
		void increaselevel(){level++;}
		void increasescore(int a){score+=a;}
		void increaselife(){life++;}
ScoreBoard(){
level =0 ;
score =0 ;
life= 0 ;

}
};

#endif /* SCOREBOARD_H_ */
