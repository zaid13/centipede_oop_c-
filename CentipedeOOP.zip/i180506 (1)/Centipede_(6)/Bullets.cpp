/*
 * Bullets.cpp
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#include "Bullets.h"


void draw(){
	DrawLine( 600 , 500 ,  50  , 50 , 7 , colors[YELLOW] );
//		DrawCircle(600 , 500 ,50,colors[RED]);

	cout<<"reached i66666666666666666666666666666n fire "<<endl;
}
