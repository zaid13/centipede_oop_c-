/*
 * Flea.h
 *
 *  Created on: May 2, 2019
 *      Author: zaid
 */

#ifndef FLEA_H_
#define FLEA_H_
#include <GL/glut.h>
#include "util.h"
#include "MoveableObject.h"
class Flea :public MoveableObject{
bool fleaOn;
bool productive;
public:
	virtual	void  draw(){
if(fleaOn)
{		DrawSquare( p.getx() , p.gety() ,30,colors[RED]);
DrawSquare( p.getx()+5 , p.gety()+5 ,10,colors[GREEN]);



if(p.gety()<100 ){fleaOn= false;}
}
	}
int Fleagetx(){return this->p.getx();}
int Fleagety(){return this->p.gety();}
void Fleaposition(int a,int b){
	p.setx(a);
	p.sety(b);
}
void flyeron(){fleaOn = true;}
void flyeroff(){fleaOn = false;}
bool getflyerstatus(){return fleaOn;}
bool getproductive(){return productive;}
void flyerYesProductive(){productive = true;}
void flyerNOProductive(){productive = false;}

};

#endif /* FLEA_H_ */
